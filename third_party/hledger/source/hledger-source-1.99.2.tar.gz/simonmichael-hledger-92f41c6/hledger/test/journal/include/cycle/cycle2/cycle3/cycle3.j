include ../../cycle.j
