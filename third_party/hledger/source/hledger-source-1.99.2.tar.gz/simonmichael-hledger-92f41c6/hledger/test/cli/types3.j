account B  ; type: Expense
