## Achievements

Some project achievements to unlock.
Being a software maintainer means unending toil in mostly-obscurity, so you've got to seek out the fun where you can!
<!-- https://www.reddit.com/r/haskell/comments/eddwbu/top_nonprogrammingrelated_haskell_apps -->

- ~~1.0 release~~
- ~~packaged in major distros, binaries available~~
- ~~pretty good reference docs~~
- ~~100 committers~~
- ~~1k github stars~~
- ~~among top 50 starred haskell projects on github~~
- ~~discussed on Hacker News~~
- ~~match ledger IRC channel size~~
- ~~among top 40 starred haskell projects on github~~
- ~~multiple people providing support~~
- ~~pretty good tutorial docs~~
- ~~pretty good cookbook docs~~
- ~~100 IRC chatters~~
- ~~2k github stars~~
- ~~1 low regression release (no new regressions found within 3 months of major release)~~
- ~~in top 30 github starred haskell projects~~
- ~~in top 20 github starred haskell projects~~
- **200 committers**
- **2.0 release**
- **best in class for investment tracking**
- **consistently mentioned in "good Haskell apps" discussions**
- **2 low regression releases in a row**
- **match ledger committers**
- **match beancount stars**
- **match ledger stars**
- **in top 10 github starred haskell projects**
- **match ledger speed**
- **3 low regression releases in a row**
- **4 low regression releases in a row**
<!--
mail lists are a choice these days, we don't use ours much
- **match beancount mail list**
- **match ledger mail list**
-->

### Stars

- [Github stars history](https://star-history.com/#simonmichael/hledger&ledger/ledger&beancount/beancount&rustledger/rustledger&Date), with Ledger and Beancount

- [All Github-starred Haskell projects](https://github.com/search?o=desc&q=language%3AHaskell++stars:>4000&ref=searchresults&s=stars&type=repositories) rank:

|      | all projects | non programming tools
|------|--------------|-------------------------------------------------
| 2026 | #13          | #4 (after pandoc, simplex chat, kmonad)
| 2025 | #19          | #5 (after pandoc, simplex chat, kmonad, cardano)
| 2023 | #32          |
| 2022 | #34          |
| 2020 | #36          |
| 2018 | #53          |
| 2017 | #54          |
| 2016 | #71          |

- [Top 100 Github-starred Haskell projects](https://github.com/EvanLi/Github-Ranking/blob/master/Top100/Haskell.md) (manually updated)

See also: [ROADMAP](ROADMAP.md)
